/* Nutrition & Gut Health Trivia
 * 20 questions: 10 easy, 5 moderate, 5 hard
 * Odd-numbered (1, 3, 5...) = English
 * Even-numbered (2, 4, 6...) = Spanish
 * Content adapted from "What type of questions should I focus on for my Activity Center" PDF
 */

const QUESTIONS = [
  // 1 — easy — EN
  {
    lang: "en",
    difficulty: "easy",
    category: "Hydration",
    question: "About how much water do most older adults need each day to help prevent constipation?",
    choices: [
      "300–500 ml",
      "1500–2000 ml",
      "4000–5000 ml",
      "Only when thirsty"
    ],
    answer: 1,
    explanation: "Most seniors should aim for roughly 1500–2000 ml (about 6–8 cups) of fluids per day. Staying hydrated keeps stools soft and supports regular digestion."
  },
  // 2 — easy — ES
  {
    lang: "es",
    difficulty: "easy",
    category: "Fibra",
    question: "¿Cuál de estos alimentos es una buena fuente de fibra?",
    choices: [
      "Pollo a la parrilla",
      "Queso amarillo",
      "Frijoles y avena",
      "Mantequilla"
    ],
    answer: 2,
    explanation: "Los granos enteros, frutas, verduras y legumbres (como frijoles, lentejas y avena) son las principales fuentes de fibra dietética."
  },
  // 3 — easy — EN
  {
    lang: "en",
    difficulty: "easy",
    category: "Probiotics",
    question: "Which of these foods is a common source of probiotics (live beneficial bacteria)?",
    choices: [
      "White bread",
      "Yogurt with live cultures",
      "Butter",
      "Soda"
    ],
    answer: 1,
    explanation: "Yogurt with live and active cultures, kefir, and sauerkraut deliver live beneficial bacteria (probiotics) that support a healthy gut."
  },
  // 4 — easy — ES
  {
    lang: "es",
    difficulty: "easy",
    category: "Digestión y edad",
    question: "Con la edad, ¿qué cambio digestivo es MÁS común en los adultos mayores?",
    choices: [
      "Digestión mucho más rápida",
      "Estreñimiento y digestión más lenta",
      "Mayor producción de saliva",
      "Desaparición del reflujo"
    ],
    answer: 1,
    explanation: "Con la edad, el tránsito intestinal se vuelve más lento, lo que puede causar estreñimiento. El reflujo y la hinchazón también suelen aumentar."
  },
  // 5 — easy — EN
  {
    lang: "en",
    difficulty: "easy",
    category: "Calcium",
    question: "Older adults are commonly advised to get about how much calcium per day for bone health?",
    choices: [
      "200 mg",
      "600 mg",
      "1200 mg",
      "3000 mg"
    ],
    answer: 2,
    explanation: "Many guidelines recommend about 1200 mg of calcium per day for older adults to help maintain bone strength. Dairy, fortified plant milks, and leafy greens are good sources."
  },
  // 6 — easy — ES
  {
    lang: "es",
    difficulty: "easy",
    category: "Sodio",
    question: "Para ayudar a controlar la presión arterial, ¿cuál es un límite diario de sodio recomendado para muchos adultos mayores?",
    choices: [
      "500 mg",
      "1500 mg",
      "5000 mg",
      "10 000 mg"
    ],
    answer: 1,
    explanation: "Limitar el sodio a alrededor de 1500 mg al día puede ayudar a controlar la presión arterial. Esto significa moderar los alimentos procesados y la sal añadida."
  },
  // 7 — easy — EN
  {
    lang: "en",
    difficulty: "easy",
    category: "Movement",
    question: "How does regular gentle exercise (like walking) usually affect digestion?",
    choices: [
      "It slows digestion down",
      "It helps food move through the gut",
      "It has no effect on digestion",
      "It only helps if it's intense"
    ],
    answer: 1,
    explanation: "Daily movement, even gentle walking, helps stimulate the muscles of the digestive tract and supports more regular bowel habits."
  },
  // 8 — easy — ES
  {
    lang: "es",
    difficulty: "easy",
    category: "Prebióticos",
    question: "¿Cuál de estos alimentos es una buena fuente de prebióticos (fibra que alimenta a las bacterias buenas)?",
    choices: [
      "Refresco de cola",
      "Ajo, cebolla y plátanos",
      "Tocino",
      "Helado"
    ],
    answer: 1,
    explanation: "Los prebióticos son fibras que alimentan a las bacterias beneficiosas del intestino. El ajo, la cebolla, los plátanos y la avena son fuentes comunes."
  },
  // 9 — easy — EN
  {
    lang: "en",
    difficulty: "easy",
    category: "Mediterranean diet",
    question: "Which eating pattern is most often linked with better gut diversity and reduced frailty in older adults?",
    choices: [
      "Mediterranean-style diet",
      "Diet high in fried foods",
      "All-meat diet",
      "Skipping meals regularly"
    ],
    answer: 0,
    explanation: "A Mediterranean-style diet — rich in vegetables, fruits, whole grains, legumes, olive oil, and fish — is consistently linked to a more diverse gut microbiome and lower frailty in seniors."
  },
  // 10 — easy — ES
  {
    lang: "es",
    difficulty: "easy",
    category: "Señales de alarma",
    question: "¿Cuál de estas señales NO es un cambio digestivo normal del envejecimiento y debe consultarse con un médico?",
    choices: [
      "Sentirse algo más lleno después de comer",
      "Sangre en las heces o pérdida de peso involuntaria",
      "Necesitar un poco más de fibra",
      "Tener sed con menos frecuencia"
    ],
    answer: 1,
    explanation: "La sangre en las heces, la pérdida de peso sin razón, los vómitos persistentes o el dolor intenso son señales de alarma. Siempre deben evaluarse por un profesional de salud."
  },
  // 11 — hard — EN
  {
    lang: "en",
    difficulty: "hard",
    category: "Microbiome diversity",
    question: "A popular gut-health guideline suggests aiming for about how many different plant foods each week to support microbiome diversity?",
    choices: [
      "3 plants",
      "10 plants",
      "30 plants",
      "100 plants"
    ],
    answer: 2,
    explanation: "Researchers have popularized the goal of about 30 different plant foods per week — fruits, vegetables, whole grains, legumes, nuts, seeds, herbs and spices — to encourage a more diverse microbiome."
  },
  // 12 — moderate — ES
  {
    lang: "es",
    difficulty: "moderate",
    category: "Probióticos vs. prebióticos",
    question: "¿Cuál es la diferencia entre probióticos y prebióticos?",
    choices: [
      "Son exactamente lo mismo",
      "Probióticos son bacterias vivas; prebióticos son la fibra que las alimenta",
      "Probióticos son medicinas; prebióticos son vitaminas",
      "Probióticos solo vienen en pastillas; prebióticos solo en jugos"
    ],
    answer: 1,
    explanation: "Los probióticos son microorganismos vivos beneficiosos (como en el yogur o el kéfir). Los prebióticos son las fibras que alimentan a esas bacterias (como en el ajo o la avena)."
  },
  // 13 — moderate — EN
  {
    lang: "en",
    difficulty: "moderate",
    category: "Common mistakes",
    question: "Which of these is a common mistake when trying to improve gut health?",
    choices: [
      "Drinking water with meals",
      "Adding a lot of fiber very quickly",
      "Eating a variety of vegetables",
      "Going for a short walk after lunch"
    ],
    answer: 1,
    explanation: "Adding fiber too quickly can cause bloating, gas, and discomfort. It's better to increase fiber gradually and drink plenty of water alongside it."
  },
  // 14 — hard — ES
  {
    lang: "es",
    difficulty: "hard",
    category: "Omega-3",
    question: "Los ácidos grasos omega-3, presentes en pescados como el salmón, se asocian principalmente con beneficios para…",
    choices: [
      "La salud del cerebro y la función cognitiva",
      "Solo el color de la piel",
      "El crecimiento del cabello únicamente",
      "Reducir la necesidad de dormir"
    ],
    answer: 0,
    explanation: "Los omega-3 (en salmón, sardinas, nueces y semillas de linaza) apoyan la salud del cerebro, el corazón y pueden ayudar a la función cognitiva en adultos mayores."
  },
  // 15 — moderate — EN
  {
    lang: "en",
    difficulty: "moderate",
    category: "GERD & reflux",
    question: "Which everyday habit can make reflux (GERD) worse in many older adults?",
    choices: [
      "Eating a small breakfast",
      "Lying down right after a large late meal",
      "Drinking water during the day",
      "Walking after lunch"
    ],
    answer: 1,
    explanation: "Eating large meals late at night and then lying down can worsen reflux. Smaller meals earlier in the evening, and staying upright for a couple of hours afterward, often help."
  },
  // 16 — moderate — ES
  {
    lang: "es",
    difficulty: "moderate",
    category: "Boca y fibra",
    question: "¿Cómo pueden los problemas dentales y la disminución de saliva afectar la alimentación de los adultos mayores?",
    choices: [
      "Hacen que la comida sepa mejor",
      "Dificultan masticar y tragar alimentos altos en fibra",
      "Aumentan automáticamente la ingesta de verduras",
      "No tienen ningún efecto sobre la dieta"
    ],
    answer: 1,
    explanation: "Los problemas dentales y la boca seca dificultan masticar y tragar frutas, verduras y granos enteros, lo que puede reducir la ingesta de fibra. Cocinar las verduras al vapor o usar batidos puede ayudar."
  },
  // 17 — hard — EN
  {
    lang: "en",
    difficulty: "hard",
    category: "Butyrate",
    question: "When gut bacteria ferment fiber, they produce a short-chain fatty acid called butyrate. Why does butyrate matter?",
    choices: [
      "It's a major fuel for cells lining the colon and helps reduce inflammation",
      "It raises blood sugar quickly",
      "It removes all bacteria from the gut",
      "It has no known effect in humans"
    ],
    answer: 0,
    explanation: "Butyrate is a short-chain fatty acid produced when beneficial bacteria ferment fiber. It feeds the cells of the colon lining and is linked to lower gut inflammation."
  },
  // 18 — hard — ES
  {
    lang: "es",
    difficulty: "hard",
    category: "Bifidobacterias y lactobacilos",
    question: "El consumo regular de probióticos puede ayudar a aumentar los niveles de dos grupos de bacterias beneficiosas. ¿Cuáles son?",
    choices: [
      "Salmonella y E. coli",
      "Bifidobacterias y lactobacilos",
      "Estafilococos y estreptococos",
      "Levaduras y mohos"
    ],
    answer: 1,
    explanation: "Los estudios muestran que los probióticos pueden aumentar las bifidobacterias y los lactobacilos, dos grupos de bacterias asociadas con un intestino más sano."
  },
  // 19 — hard — EN
  {
    lang: "en",
    difficulty: "hard",
    category: "Synbiotics",
    question: "What is a 'synbiotic'?",
    choices: [
      "A type of antibiotic",
      "A combination of probiotics and prebiotics",
      "A sugar-free sweetener",
      "A multivitamin without minerals"
    ],
    answer: 1,
    explanation: "A synbiotic combines probiotics (beneficial bacteria) with prebiotics (the fibers that feed them). Studies suggest synbiotics may improve stool frequency and lower inflammation."
  },
  // 20 — moderate — ES
  {
    lang: "es",
    difficulty: "moderate",
    category: "Medicamentos y digestión",
    question: "Algunos medicamentos comunes en adultos mayores pueden afectar la digestión. ¿Cuál es la mejor acción si nota estreñimiento, diarrea u otros cambios después de empezar un medicamento?",
    choices: [
      "Dejar de tomar el medicamento sin avisar a nadie",
      "Doblar la dosis para compensar",
      "Hablar con su médico o farmacéutico antes de hacer cambios",
      "Ignorar los síntomas durante varios meses"
    ],
    answer: 2,
    explanation: "Muchos medicamentos (analgésicos, antiácidos, diuréticos, antibióticos) pueden alterar la digestión. Lo más seguro es comentar los cambios con el médico o farmacéutico antes de modificar la dosis."
  }
];

/* ---------- Validation ---------- */
function validateQuestions() {
  const errors = [];
  if (QUESTIONS.length !== 20) errors.push(`Expected 20 questions, got ${QUESTIONS.length}`);
  const counts = { easy: 0, moderate: 0, hard: 0 };
  QUESTIONS.forEach((q, i) => {
    const n = i + 1;
    if (!q.choices || q.choices.length !== 4) errors.push(`Q${n}: must have 4 choices`);
    if (typeof q.answer !== "number" || q.answer < 0 || q.answer > 3) errors.push(`Q${n}: answer index out of range`);
    if (!q.explanation) errors.push(`Q${n}: missing explanation`);
    const expectedLang = n % 2 === 1 ? "en" : "es";
    if (q.lang !== expectedLang) errors.push(`Q${n}: expected ${expectedLang}, got ${q.lang}`);
    if (counts[q.difficulty] === undefined) errors.push(`Q${n}: invalid difficulty ${q.difficulty}`);
    else counts[q.difficulty]++;
  });
  if (counts.easy !== 10) errors.push(`Expected 10 easy, got ${counts.easy}`);
  if (counts.moderate !== 5) errors.push(`Expected 5 moderate, got ${counts.moderate}`);
  if (counts.hard !== 5) errors.push(`Expected 5 hard, got ${counts.hard}`);
  return errors;
}

const validationErrors = validateQuestions();
if (validationErrors.length) {
  console.error("Question validation errors:", validationErrors);
} else {
  console.log("Question validation passed: 20 questions, 10/5/5 difficulty, language alternation OK.");
}

/* ---------- UI strings (bilingual labels) ---------- */
const LABELS = {
  en: {
    difficulty: { easy: "Easy", moderate: "Moderate", hard: "Hard" },
    progress: (n, total) => `Question ${n} of ${total}`,
    score: "Score",
    correct: "Correct!",
    incorrect: "Not quite.",
    correctAnswerIs: "Correct answer:",
    next: "Next question",
    finish: "See results",
    why: "Why?"
  },
  es: {
    difficulty: { easy: "Fácil", moderate: "Moderada", hard: "Difícil" },
    progress: (n, total) => `Pregunta ${n} de ${total}`,
    score: "Puntaje",
    correct: "¡Correcto!",
    incorrect: "Casi.",
    correctAnswerIs: "Respuesta correcta:",
    next: "Siguiente pregunta",
    finish: "Ver resultados",
    why: "¿Por qué?"
  }
};

/* ---------- Game state ---------- */
const state = {
  index: 0,
  score: 0,
  answered: false,
  selected: null
};

/* ---------- DOM refs ---------- */
const els = {
  start: document.getElementById("start-screen"),
  game: document.getElementById("game-screen"),
  end: document.getElementById("end-screen"),
  startBtn: document.getElementById("start-btn"),
  progressText: document.getElementById("progress-text"),
  progressFill: document.getElementById("progress-fill"),
  scoreText: document.getElementById("score-text"),
  difficultyBadge: document.getElementById("difficulty-badge"),
  langBadge: document.getElementById("lang-badge"),
  category: document.getElementById("category"),
  questionText: document.getElementById("question-text"),
  choices: document.getElementById("choices"),
  feedback: document.getElementById("feedback"),
  feedbackTitle: document.getElementById("feedback-title"),
  feedbackBody: document.getElementById("feedback-body"),
  nextBtn: document.getElementById("next-btn"),
  finalScore: document.getElementById("final-score"),
  finalMessage: document.getElementById("final-message"),
  restartBtn: document.getElementById("restart-btn"),
  restartFromGameBtn: document.getElementById("restart-from-game-btn")
};

/* ---------- Render ---------- */
function setScreen(name) {
  els.start.hidden = name !== "start";
  els.game.hidden = name !== "game";
  els.end.hidden = name !== "end";
}

function renderQuestion() {
  const q = QUESTIONS[state.index];
  const L = LABELS[q.lang];
  state.answered = false;
  state.selected = null;

  // Set document lang for screen readers
  document.documentElement.setAttribute("lang", q.lang);

  els.progressText.textContent = L.progress(state.index + 1, QUESTIONS.length);
  els.progressFill.style.width = `${((state.index) / QUESTIONS.length) * 100}%`;
  els.scoreText.textContent = `${L.score}: ${state.score}`;

  els.difficultyBadge.textContent = L.difficulty[q.difficulty];
  els.difficultyBadge.dataset.level = q.difficulty;

  els.langBadge.textContent = q.lang === "en" ? "EN" : "ES";
  els.langBadge.setAttribute("aria-label", q.lang === "en" ? "English" : "Español");

  els.category.textContent = q.category;
  els.questionText.textContent = q.question;

  // Build choices
  els.choices.innerHTML = "";
  const letters = ["A", "B", "C", "D"];
  q.choices.forEach((choiceText, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "choice";
    btn.setAttribute("role", "listitem");
    btn.dataset.index = String(i);
    btn.innerHTML = `
      <span class="choice-letter" aria-hidden="true">${letters[i]}</span>
      <span class="choice-text">${escapeHtml(choiceText)}</span>
      <span class="choice-mark" aria-hidden="true"></span>
    `;
    btn.setAttribute("aria-label", `${letters[i]}. ${choiceText}`);
    btn.addEventListener("click", () => selectChoice(i));
    els.choices.appendChild(btn);
  });

  // Reset feedback
  els.feedback.hidden = true;
  els.feedback.className = "feedback";
  els.nextBtn.hidden = true;
  els.nextBtn.textContent = state.index === QUESTIONS.length - 1 ? L.finish : L.next;

  // Focus first choice for keyboard users
  const firstChoice = els.choices.querySelector(".choice");
  if (firstChoice) firstChoice.focus();
}

function selectChoice(i) {
  if (state.answered) return;
  state.answered = true;
  state.selected = i;
  const q = QUESTIONS[state.index];
  const L = LABELS[q.lang];
  const correct = i === q.answer;
  if (correct) state.score++;

  // Mark buttons
  const buttons = els.choices.querySelectorAll(".choice");
  buttons.forEach((btn, idx) => {
    btn.disabled = true;
    if (idx === q.answer) btn.classList.add("is-correct");
    if (idx === i && !correct) btn.classList.add("is-wrong");
    if (idx === i) btn.setAttribute("aria-pressed", "true");
  });

  // Feedback
  els.feedback.hidden = false;
  els.feedback.classList.add(correct ? "is-correct" : "is-wrong");
  els.feedbackTitle.textContent = correct ? L.correct : L.incorrect;
  const correctLetter = ["A", "B", "C", "D"][q.answer];
  const correctText = q.choices[q.answer];
  const lead = correct ? "" : `${L.correctAnswerIs} ${correctLetter}. ${correctText}. `;
  els.feedbackBody.textContent = `${lead}${q.explanation}`;

  // Update score display
  els.scoreText.textContent = `${L.score}: ${state.score}`;

  els.nextBtn.hidden = false;
  els.nextBtn.focus();
}

function nextQuestion() {
  if (state.index < QUESTIONS.length - 1) {
    state.index++;
    renderQuestion();
  } else {
    showEnd();
  }
}

function showEnd() {
  setScreen("end");
  els.finalScore.textContent = `${state.score} / ${QUESTIONS.length}`;
  const pct = Math.round((state.score / QUESTIONS.length) * 100);
  let msg;
  if (pct >= 90) msg = "Outstanding! You're a nutrition champion. / ¡Excelente! Eres un campeón de la nutrición.";
  else if (pct >= 70) msg = "Great job! You know your gut health. / ¡Muy bien! Conoces la salud intestinal.";
  else if (pct >= 50) msg = "Nice effort — keep learning! / ¡Buen esfuerzo, sigue aprendiendo!";
  else msg = "Thanks for playing — try again to learn more! / ¡Gracias por jugar! Inténtalo otra vez para aprender más.";
  els.finalMessage.textContent = msg;
  els.restartBtn.focus();
}

function restart() {
  state.index = 0;
  state.score = 0;
  state.answered = false;
  setScreen("game");
  renderQuestion();
}

function start() {
  state.index = 0;
  state.score = 0;
  setScreen("game");
  renderQuestion();
}

/* ---------- Helpers ---------- */
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);
}

/* ---------- Keyboard support ---------- */
document.addEventListener("keydown", (e) => {
  // Only when on game screen
  if (els.game.hidden) return;

  const key = e.key.toLowerCase();
  if (!state.answered && ["a", "b", "c", "d", "1", "2", "3", "4"].includes(key)) {
    const map = { a: 0, b: 1, c: 2, d: 3, "1": 0, "2": 1, "3": 2, "4": 3 };
    const idx = map[key];
    selectChoice(idx);
    e.preventDefault();
  } else if (state.answered && (e.key === "Enter" || e.key === " ")) {
    if (!els.nextBtn.hidden) {
      nextQuestion();
      e.preventDefault();
    }
  }
});

/* ---------- Wire buttons ---------- */
els.startBtn.addEventListener("click", start);
els.nextBtn.addEventListener("click", nextQuestion);
els.restartBtn.addEventListener("click", restart);
els.restartFromGameBtn.addEventListener("click", restart);

// Initial state
setScreen("start");
